int main ()
{ bool a; bool x; int res;

  read(x);
  res = 0;
  using a 				// Variable no es entera
  x times 				// Expresion no es entera
  do res = res+1 ; 

  return 0;
}
