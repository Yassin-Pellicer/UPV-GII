// Ejemplo de uso de operadores aritmeticos.
// Debe devolver el mismo numero elevado al cuadrado
//--------------------------------------------------
int main ()
{
  for a in range (2, 7){
   print(a); 
  }
  return 0;
}
