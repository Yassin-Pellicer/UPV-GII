//---------------------------------------------------------
int main ( )
{
  int c;
  c = -1;
  switch c { less { print(1); } equal {print(2);} greater {print(3);  }  }
  // imprime 1
  return 0;
}
