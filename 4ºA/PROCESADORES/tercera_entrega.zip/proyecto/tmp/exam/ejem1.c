//El id del `switch' debe ser entero
//---------------------------------------------------------
int main ( )
{
  bool c;

  c = true;
  switch c { less { print(1); } equal {print(2);} greater {print(3);  }  }

  
  return 0;
}
