// Ejemplo de entradas y salidas: 5 -> 5 6 15  10-> 10 11 55
int main ()
{ int a; int x; int res;

  read(x);
  res = 0;
  using a x times do res = res+a ;
  print(x) ;
  print(a) ;
  print(res) ; 

  return 0;
}
