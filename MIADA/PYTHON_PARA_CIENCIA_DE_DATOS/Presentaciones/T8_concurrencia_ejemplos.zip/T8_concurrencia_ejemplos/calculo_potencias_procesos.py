import os
from time import time
from random import randrange
from multiprocessing import *

def calculo_potencias(numeros):
    for n in numeros:
        potencia = n ** n

if __name__ == "__main__":
    # Creamos una lista de 10^8 enteros
    lista_numeros = [randrange(1, 50, 1) for i in range(100000000)]
    
    medio = len(lista_numeros) // 2
    primera_mitad = lista_numeros[:medio]
    segunda_mitad = lista_numeros[medio:]

    p1 = Process(target = calculo_potencias, args = (primera_mitad,))
    p2 = Process(target = calculo_potencias, args = (segunda_mitad,))

    t_ini = time()
    p1.start(); p2.start()
    p1.join(); p2.join()
    t_fin = time()
    print(f"Tiempo de ejecución (PROCESOS): {(t_fin-t_ini)*10**3:8.2f}ms")