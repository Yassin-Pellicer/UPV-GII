import os
from time import time
from random import randrange

def calculo_potencias(numeros):
    for n in numeros:
        potencia = n ** n

if __name__ == "__main__":
    # Creamos una lista de 10^8 enteros
    lista_numeros = [randrange(1, 50, 1) for i in range(100000000)]

    t_ini = time()
    calculo_potencias(lista_numeros)
    t_fin = time()

    print(f"Tiempo de ejecución (SIN HILOS): {(t_fin-t_ini)*10**3:8.2f}ms")