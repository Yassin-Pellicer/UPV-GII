import requests
import time
from threading import *
from queue import Queue


def descarga_urls(lista_urls, cola):
    print(f"Descarga ({current_thread().name}): INICIO")
    for i in range(len(lista_urls)):
        req = requests.get(lista_urls[i])
        print(f"\tDescarga ({current_thread().name}): añadiendo request a la cola")
        cola.put(req)
    cola.put(None)
    print(f"\tDescarga ({current_thread().name}): FIN")


def procesa_fichero(cola, n_productores=0):
    print(f"Procesa: INICIO (n_productores: {n_productores})")
    i = 1
    while True:
        req = cola.get()
        if req == None:
            n_productores -= 1
            print(f"\tProcesa: None recibido (productores pendientes: {n_productores})")
            if n_productores == 0:
                break
            else:       
                cola.task_done()
                continue
        nombre_fichero = f"fichero{i:0>2d}.csv"
        print(f"\tProcesa: request {i} recibido: guardando {nombre_fichero}...")
        with open(nombre_fichero, "w") as fcsv:
            fcsv.write(req.text)
        cola.task_done()
        i += 1
    
    print(f"\tProcesa: No más productores!")
    cola.task_done()
    print(f"\tProcesa: FIN")



if __name__ == "__main__":
    lista_sitios = [ "https://valencia.opendatasoft.com/api/explore/v2.1/catalog/datasets/estat-transit-temps-real-estado-trafico-tiempo-real/exports/csv?lang=es&timezone=Europe%2FBerlin&use_labels=true&delimiter=%3B",
             "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/jcdecaux_bike_data/exports/csv?lang=en&timezone=Europe%2FBerlin&use_labels=true&delimiter=%3B" 
           ] * 5
    mitad = len(lista_sitios) // 2
    cola = Queue()
    
    print(f"Programa principal: creando hilos")
    t1 = Thread(name='g', target=procesa_fichero, args=(cola,), kwargs={'n_productores' : 2})
    t2 = Thread(name='d1', target=descarga_urls, args=(lista_sitios[:mitad], cola))
    t3 = Thread(name='d2', target=descarga_urls, args=(lista_sitios[mitad:], cola))
    
    t1.start(); t2.start() ;  t3.start();  
    
    print(f"Programa principal: Espeando hilos descarga")
    t2.join() ;  t3.join()
    
    print(f"Programa principal: Esperando fin del procesamiento")
    cola.join()
    
    print(f"FIN programa principal")
