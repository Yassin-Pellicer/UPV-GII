import requests
import time

def descarga_urls(lista_urls, nom_ficheros):
    for i in range(len(lista_urls)):
        req = requests.get(lista_urls[i])
        with open(nom_ficheros[i], "w") as fcsv:
            fcsv.write(req.text)

if __name__ == "__main__":
    lista_sitios = [ 
        "https://valencia.opendatasoft.com/api/explore/v2.1/catalog/datasets/estat-transit-temps-real-estado-trafico-tiempo-real/exports/csv?lang=es&timezone=Europe%2FBerlin&use_labels=true&delimiter=%3B",
        "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/jcdecaux_bike_data/exports/csv?lang=en&timezone=Europe%2FBerlin&use_labels=true&delimiter=%3B" 
        ] * 5
    lista_nombres_fichero = [f"fichero{i:0>2d}.csv" 
                             for i in range(1,len(lista_sitios)+1)]

    t_ini = time.time()
    descarga_urls(lista_sitios, lista_nombres_fichero)
    t_fin = time.time()  
    print(f"Tiempo de ejecución (SIN HILOS): {(t_fin-t_ini)*10**3:8.2f}ms")