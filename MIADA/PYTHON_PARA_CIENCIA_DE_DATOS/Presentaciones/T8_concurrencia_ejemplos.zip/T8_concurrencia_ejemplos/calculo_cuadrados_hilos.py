from threading import *
import os

def calculo_cuadrados(numeros):
    id_hilo = current_thread().name # Identificador hilo
    id_proc = os.getpid()           # Identificador proceso (PID)
    for n in numeros:
        cuadrado = n * n
        print(f"{n}^2 : {cuadrado} | Hilo {id_hilo} | PID {id_proc}")

if __name__ == "__main__":
    lista_numeros = [1, 2, 3, 4, 5, 6, 7, 8]
    medio = len(lista_numeros) // 2
    primera_mitad = lista_numeros[:medio]
    segunda_mitad = lista_numeros[medio:]

    t1 = Thread(target=calculo_cuadrados, 
                name="t1", args=(primera_mitad,))
    t2 = Thread(target=calculo_cuadrados, 
                name="t2", args=(segunda_mitad,))

    t1.start()
    t2.start()

    t1.join()
    t2.join()