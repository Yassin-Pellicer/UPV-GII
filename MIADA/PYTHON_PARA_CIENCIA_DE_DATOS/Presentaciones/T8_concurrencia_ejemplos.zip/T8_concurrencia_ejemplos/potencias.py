
def calculo_potencias(numeros):
    for n in numeros:
        potencia = n ** n

if __name__ == "__main__":
    # Creamos una lista de 10^8 enteros
    lista_numeros = [randrange(1, 50, 1) for i in range(100000000)]
    calculo_potencias(lista_numeros)


