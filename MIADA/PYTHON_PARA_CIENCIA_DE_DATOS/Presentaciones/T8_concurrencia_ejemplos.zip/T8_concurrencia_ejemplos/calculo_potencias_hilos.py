import os
from time import time
from random import randrange
from threading import *

def calculo_potencias(numeros):
    for n in numeros:
        potencia = n ** n

if __name__ == "__main__":
    # Creamos una lista de 10^8 enteros
    lista_numeros = [randrange(1, 50, 1) for i in range(100000000)]
    
    medio = len(lista_numeros) // 2
    primera_mitad = lista_numeros[:medio]
    segunda_mitad = lista_numeros[medio:]

    t1 = Thread(target = calculo_potencias, args = (primera_mitad,))
    t2 = Thread(target = calculo_potencias, args = (segunda_mitad,))

    t_ini = time()
    t1.start(); t2.start()
    t1.join(); t2.join()
    t_fin = time()
    print(f"Tiempo de ejecución (CON HILOS): {(t_fin-t_ini)*10**3:8.2f}ms")